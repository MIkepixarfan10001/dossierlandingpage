# Videos

The three demo MP4s belong here:

- dossier-personal-injury.mp4
- dossier-commercial-real-estate.mp4
- dossier-family-law.mp4

They are kept out of this copy to keep the upload small. Drop them into this
folder, or attach them to a GitHub Release and point site/index.html at the
release URL. index.html expects them at `videos/<name>.mp4` relative to itself.
