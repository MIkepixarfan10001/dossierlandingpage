import os, subprocess, sys
from concurrent.futures import ProcessPoolExecutor
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
FPS = 30
TOTAL = 78.0
CHUNK_S = 10
NFRAMES = int(round(TOTAL * FPS))
CHUNK_F = CHUNK_S * FPS
OUT = os.path.join(HERE, 'chunks')


def render_chunk(ci):
    start = ci * CHUNK_F
    end = min(NFRAMES, start + CHUNK_F)
    final = os.path.join(OUT, f'c{ci:02d}.mp4')
    tmp = os.path.join(OUT, f'c{ci:02d}.tmp.mp4')
    ff = subprocess.Popen([
        'ffmpeg', '-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', str(FPS),
        '-c:v', 'mjpeg', '-i', '-', '-an', '-vf', 'format=yuv420p', '-c:v', 'libx264',
        '-crf', '18', '-preset', 'veryfast', '-pix_fmt', 'yuv420p', '-r', str(FPS), '-g', '30',
        tmp], stdin=subprocess.PIPE)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width': 1920, 'height': 1080})
        pg.goto('file://' + os.path.join(HERE, 'demo.html'))
        pg.evaluate('document.fonts.ready')
        for f in range(start, end):
            pg.evaluate(f'renderAt({f / FPS})')
            ff.stdin.write(pg.screenshot(type='jpeg', quality=92))
        b.close()
    ff.stdin.close()
    rc = ff.wait()
    if rc != 0:
        raise SystemExit(f'ffmpeg failed on chunk {ci}')
    os.rename(tmp, final)
    return ci


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    n = (NFRAMES + CHUNK_F - 1) // CHUNK_F
    with ProcessPoolExecutor(2) as ex:
        for ci in ex.map(render_chunk, range(n)):
            print('chunk done', ci, flush=True)
    print('frames', NFRAMES, 'chunks', n)
