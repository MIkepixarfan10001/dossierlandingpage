import os, subprocess, math, sys
from concurrent.futures import ProcessPoolExecutor
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
FPS = 30
CHUNK_S = 10
CHUNK_F = CHUNK_S * FPS
OUT = os.path.join(HERE, 'chunks')


def get_total():
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width': 1920, 'height': 1080})
        pg.goto('file://' + os.path.join(HERE, 'demo.html'))
        total = pg.evaluate('window.TOTAL')
        b.close()
    return total


def render_chunk(args):
    ci, nframes = args
    start = ci * CHUNK_F
    end = min(nframes, start + CHUNK_F)
    final = os.path.join(OUT, f'c{ci:02d}.mp4')
    tmp = os.path.join(OUT, f'c{ci:02d}.tmp.mp4')
    ff = subprocess.Popen([
        'ffmpeg', '-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', str(FPS),
        '-c:v', 'mjpeg', '-i', '-', '-an', '-vf', 'format=yuv420p', '-c:v', 'libx264',
        '-crf', '18', '-preset', 'veryfast', '-pix_fmt', 'yuv420p', '-r', str(FPS), '-g', '30',
        tmp], stdin=subprocess.PIPE)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width': 1920, 'height': 1080})
        pg.goto('file://' + os.path.join(HERE, 'demo.html'))
        pg.evaluate('document.fonts.ready')
        for f in range(start, end):
            pg.evaluate(f'renderAt({f / FPS})')
            ff.stdin.write(pg.screenshot(type='jpeg', quality=92))
        b.close()
    ff.stdin.close()
    rc = ff.wait()
    if rc != 0:
        raise SystemExit(f'ffmpeg failed on chunk {ci}')
    os.rename(tmp, final)
    return ci


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    total = get_total()
    nframes = int(math.ceil(total * FPS))
    n = (nframes + CHUNK_F - 1) // CHUNK_F
    print('total seconds', total, 'frames', nframes, 'chunks', n, flush=True)
    with ProcessPoolExecutor(2) as ex:
        for ci in ex.map(render_chunk, [(i, nframes) for i in range(n)]):
            print('chunk done', ci, flush=True)
