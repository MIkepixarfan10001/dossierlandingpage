import sys, os
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
times = [float(x) for x in sys.argv[1:]]
os.makedirs(os.path.join(HERE, 'probe'), exist_ok=True)
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width': 1920, 'height': 1080})
    errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    pg.goto('file://' + os.path.join(HERE, 'demo.html'))
    pg.evaluate('document.fonts.ready')
    for t in times:
        pg.evaluate(f'renderAt({t})')
        pg.screenshot(path=os.path.join(HERE, 'probe', f't{t:06.2f}.jpg'), type='jpeg', quality=92)
    print('errors:', errs)
    b.close()
