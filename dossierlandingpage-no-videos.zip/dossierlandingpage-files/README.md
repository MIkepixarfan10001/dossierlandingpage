# Dossier

Marketing site and outreach demo videos for **Dossier** — a document-retrieval
assistant for law firms. It sits on top of Word and Google Docs: the drafter
types a trigger (`␣␣D` for a date, `␣␣$` for an amount, `␣␣?` for a detail),
Dossier finds the fact in the firm's own case files and fills it in with a
citation to the source document and page.

## What's in here

```
site/      the landing page — open site/index.html in a browser
demos/     the animated mockups each video was filmed from
```

### site/

A single self-contained HTML page: no build step, no dependencies beyond two
Google Fonts (Bodoni Moda for display, Public Sans for text). The three videos
are in `site/videos/`; the page currently embeds the personal injury one.

The "Try a demo" button has no destination yet (`href="#"`).

### demos/

One folder per video. Each contains:

- `demo.html` — the mockup. It is a deterministic timeline, not a recording:
  `window.renderAt(t)` draws the exact frame for time `t` in seconds, and
  `window.TOTAL` is the length. Opening it in a browser shows frame 0.
- `probe.py` — screenshots given times into `probe/`, for checking layout
  before a full render: `python3 probe.py 11 21.6 46`
- `render.py` — renders every frame through ffmpeg into `chunks/`.

## Re-rendering a video

Requires Python 3 with Playwright (Chromium) and ffmpeg.

```bash
cd demos/family-law
python3 render.py                     # writes chunks/c00.mp4, c01.mp4, …
cd chunks
ls c*.mp4 | sort | sed "s/^/file '/;s/$/'/" > list.txt
ffmpeg -f concat -safe 0 -i list.txt -c copy -an -movflags +faststart \
  ../../../site/videos/dossier-family-law.mp4
```

Output spec for all three: 1920×1080, 30 fps, H.264 (crf 18), **no audio track
at all**. The narration is on-screen captions, each held at least three seconds.

| Video | Length | Story |
|---|---|---|
| `dossier-personal-injury.mp4` | 1:18 | Treatment date, injury detail, medical charges (Alvarez) |
| `dossier-commercial-real-estate.mp4` | 1:24 | Rent increase, renewal deadline, landlord obligations (Pelican Plaza) |
| `dossier-family-law.mp4` | 1:04 | Income, date of separation, conflicting account balances (Whitfield) |

## Notes

- **All case data is fictional.** Maria Alvarez, Pelican Plaza and the Whitfield
  matter are invented, and every video carries a "Sample data" label.
- The wordmark is Times New Roman. The machine these were rendered on only has
  Liberation Serif, which is metric-compatible, so that is what the videos show.
  Re-render on a machine with the real font to change that.
- Palette: `#101218` background, `#191C24` panels, `#E2BB66` gold accent,
  `#F2CC79` citations, `#ECEEF4` text, `#75D9AD` success, `#FF9A8E` conflicts.
